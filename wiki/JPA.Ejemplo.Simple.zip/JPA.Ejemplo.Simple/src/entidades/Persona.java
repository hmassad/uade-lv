package entidades;

import javax.persistence.*;

@Entity //Informa que es una clase persistente (esto es REQUERIDO)
@Table(name="Persona") //Mapea Tabla con Clase. Si el nombre de la clase = nombre tabla => no requiere especificar 
public class Persona {


	private int id;
    private String nombre;
    private String apellido;
   

    public Persona() {
        
    }
    
    
    @Id //Significa que es la PK
    @GeneratedValue //Significa que es columna Identity para SQL SERVER 
    @Column(name="id")//Mapea Atributo con Columna de la DB. Si el nombre del atributo = nombre columna => no requiere especificar 
    public int getId() {
        return id;
    }
    private void setId(int id) {
        this.id = id;
    }

    @Column(name="apellido") //Si el nombre del atributo = nombre columna => no requiere especificar 
    public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	@Column(name="nombre") //Si el nombre del atributo = nombre columna => no requiere especificar 
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String toString(){
		return "PERSONA: "+ getId() + " " + getNombre() + " " + getApellido();
	}


}
