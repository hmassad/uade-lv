package ui;

import java.util.*;
import javax.persistence.*;

import entidades.Persona;

public class Main {

	
    public static void main(String[] args) {

        // Obtener el EntityManagerFactory (poner el persistent unit del persistence.xml)
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("ejemplo");

        // Crear el EntityManager
        EntityManager em = emf.createEntityManager();
        
        //Inicio Transaccion
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        //Creo una persona
        Persona persona = new Persona();
        persona.setNombre("Juan");
        persona.setApellido("Perez");
        
        //Persisto la persona
        em.persist(persona);
        
        //Commit de la Transaccion
        tx.commit();
        
        
        //Creo el query para obtener todas las Personas
        Query query = em.createQuery("SELECT p FROM Persona p");

        //Ejecuto el query
        List<Persona> personas = query.getResultList();
        
        //Muestro las personas por la consola
        for (Persona p : personas) {
			System.out.println(p);
		}
        
       
        
        //Cierro el EntityManager al finalizar
        em.close();
        
        //Cerrar EntityManagerFactory
        emf.close();
       
    }
}
