package entities;

import javax.persistence.*;

@Entity
public class Hijo {

	@Id
	@GeneratedValue
	private int id;
	
	private String nombre;
	
	private String apellido;
	
	@ManyToOne
	@JoinColumn(name="padreId")
	private Padre padre;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public Padre getPadre() {
		return padre;
	}
	public void setPadre(Padre padre) {
		this.padre = padre;
	}
	
	
	
}
