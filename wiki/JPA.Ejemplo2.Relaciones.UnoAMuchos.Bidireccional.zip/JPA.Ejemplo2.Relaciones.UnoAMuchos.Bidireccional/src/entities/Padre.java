package entities;

import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.*;

@Entity
public class Padre {

	@Id @GeneratedValue
	private int id;
	private String nombre;
	private String apellido;
	
	@OneToMany(mappedBy="padre")
	private Collection<Hijo> hijos;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public Collection<Hijo> getHijos() {
		return hijos;
	}
	public void setHijos(Collection<Hijo> hijos) {
		this.hijos = hijos;
	}
	
	public void agregarHijo(Hijo hijo){
		if(hijos == null){
			hijos = new ArrayList<Hijo>();
		}
		hijos.add(hijo);
		hijo.setPadre(this);
	}
	
	public String toString(){
		return id + " " +nombre + " " + apellido;
	}
	
	
}
