package ui;

import java.util.*;
import javax.persistence.*;

import entities.Hijo;
import entities.Padre;

public class Main {

	
    public static void main(String[] args) {

        // Obtener el EntityManagerFactory (poner el persistent unit del persistence.xml)
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("ejemplo");

        // Crear el EntityManager
        EntityManager em = emf.createEntityManager();
        
        //Inicio Transaccion
        EntityTransaction tx = em.getTransaction();
        tx.begin();

        Hijo hijo1 = new Hijo();
        hijo1.setNombre("JUAN1");
        Hijo hijo2 = new Hijo();
        hijo2.setNombre("PEDRO1");
              
        Padre padre = new Padre();
        padre.setNombre("CARLOS");
        padre.agregarHijo(hijo1);
        padre.agregarHijo(hijo2);
        
        //Persisto
        em.persist(hijo1);
        em.persist(hijo2);
        em.persist(padre);
        
        
        //Commit de la Transaccion
        tx.commit();
        
      
        //Creo el query para obtener todos los padres
        Query query = em.createQuery("SELECT p FROM Padre p");

        //Ejecuto el query
        List<Padre> padres = query.getResultList();
        
        //Muestro las personas por la consola
        for (Padre p : padres) {
			System.out.println(p);
		}
      
        //Cierro el EntityManager al finalizar la operaci�n
        em.close();
        emf.close();
    }
}
